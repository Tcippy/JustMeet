package com.justmeet.okBoomer.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.justmeet.okBoomer.model.Role;

/**
 * @author Cippitelli, Rinaldi
 *
 */

public interface RoleRepository extends JpaRepository<Role, Long>{
}
